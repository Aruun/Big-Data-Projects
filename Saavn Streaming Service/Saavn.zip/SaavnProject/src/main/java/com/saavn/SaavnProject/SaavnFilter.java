package com.saavn.SaavnProject;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.hadoop.conf.Configurable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class SaavnFilter
{

	public static class MapperClass extends Mapper<Object, Text, Text, DateAndCount> 
	{
		public static List<String> days = Arrays.asList("24","25","26","27","28","29","30");	

 		public void map(Object key, Text record, Context con) throws IOException, InterruptedException 
		{
 				
  			String[] info = record.toString().split(",");
			String songid = info[0];
			String hour = info[3];
			int hours = Integer.parseInt(hour);
			String[] date = info[4].split("-");
			String day;
			if(date.length>1){
				day = date[2];
				//Setting the time frame as 18 hours
			if(hours >= 05 && hours <= 23 )
			{
				if(days.contains(day)){
					con.write(new Text(songid), new DateAndCount(day,1));
				}
 		}
		}
		}
	}
	
	public static class DayPartitioner extends Partitioner<Text, DateAndCount> implements
    Configurable {

  private Configuration configuration;
  HashMap<String, Integer> daymap = new HashMap<String, Integer>();

  
   // Set up the months hash map in the setConf method.
   
  
  public void setConf(Configuration configuration) {
    this.configuration = configuration;
   
    daymap.put("24", 1);
    daymap.put("25", 2);
    daymap.put("26", 3);
    daymap.put("27", 4);
    daymap.put("28", 5);
    daymap.put("29", 6);
    daymap.put("30", 7);
    
    
  }

  
   // Implement the getConf method for the Configurable interface.
   
 
  public Configuration getConf() {
    return configuration;
  }

  
   
     public int getPartition(Text key, DateAndCount value, int numReduceTasks) {
    return (int) (daymap.get(value.getDate()));
  }
}


	

	public static class ReducerClass extends Reducer<Text, DateAndCount, Text, Text> 
	{

 		public void reduce(Text key, Iterable<DateAndCount> valueList, 
			Context con) throws IOException, InterruptedException 
		{
   			int song_count=0;
   			for (DateAndCount var : valueList) 
			{
				song_count+=var.getCount();
   			}
   			if(song_count>100)
   			{
   			String out = ":"+song_count;
   			con.write(key, new Text(out));
   			}
 		}
	}
	


	public static void main(String[] args) throws Exception 
	{
		
		Configuration conf;
		Job job;
			
    		conf = new Configuration();
			
    		job = Job.getInstance(conf, "adhaar1_a");
    		job.setJarByClass(SaavnFilter.class);
			
		job.setMapperClass(MapperClass.class);
    		job.setReducerClass(ReducerClass.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(DateAndCount.class);
			
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

    		FileInputFormat.addInputPath(job, new Path(args[0]));

    		FileOutputFormat.setOutputPath(job, new Path(args[1]));

    	    job.setNumReduceTasks(7);
    	    
    	    /*
    	     * Specify the partitioner class.
    	     */
    	    job.setPartitionerClass(DayPartitioner.class);
			
			
    		System.exit(job.waitForCompletion(true) ? 0 : 1);
  	}
}
